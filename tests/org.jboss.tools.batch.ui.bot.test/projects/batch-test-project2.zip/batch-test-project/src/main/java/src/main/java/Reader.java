package src.main.java;

import javax.batch.api.chunk.AbstractItemReader;
import javax.inject.Named;

@Named
public class Reader extends AbstractItemReader {

	public Reader() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object readItem() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
