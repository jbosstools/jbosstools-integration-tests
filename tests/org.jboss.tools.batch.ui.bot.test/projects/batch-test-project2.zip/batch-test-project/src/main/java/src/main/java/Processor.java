package src.main.java;

import javax.batch.api.chunk.ItemProcessor;
import javax.inject.Named;

@Named
public class Processor implements ItemProcessor {

	public Processor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object processItem(Object item) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
