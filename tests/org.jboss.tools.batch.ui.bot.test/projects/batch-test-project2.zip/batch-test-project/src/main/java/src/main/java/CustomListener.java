package src.main.java;

import javax.batch.api.listener.AbstractJobListener;

public class CustomListener extends AbstractJobListener {
		
	public CustomListener() {}
}
