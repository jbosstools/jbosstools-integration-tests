package src.main.java;

import javax.batch.api.partition.AbstractPartitionAnalyzer;
import javax.inject.Named;

@Named
public class Analyzer extends AbstractPartitionAnalyzer {

	public Analyzer() {
		// TODO Auto-generated constructor stub
	}

}
