package src.main.java;

import java.io.Serializable;

import javax.batch.api.partition.PartitionCollector;
import javax.inject.Named;

@Named
public class Collector implements PartitionCollector {

	public Collector() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Serializable collectPartitionData() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
