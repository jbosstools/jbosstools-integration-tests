package src.main.java;

import javax.batch.api.listener.AbstractStepListener;
import javax.inject.Named;

@Named
public class StepListener extends AbstractStepListener {

	public StepListener() {
		// TODO Auto-generated constructor stub
	}

}
