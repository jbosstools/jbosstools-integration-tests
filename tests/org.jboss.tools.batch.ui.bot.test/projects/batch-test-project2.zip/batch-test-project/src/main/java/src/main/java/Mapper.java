package src.main.java;

import javax.batch.api.partition.PartitionMapper;
import javax.batch.api.partition.PartitionPlan;
import javax.inject.Named;

@Named
public class Mapper implements PartitionMapper {

	public Mapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public PartitionPlan mapPartitions() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
