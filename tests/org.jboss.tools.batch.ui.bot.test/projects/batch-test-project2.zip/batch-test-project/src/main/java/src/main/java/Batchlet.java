package src.main.java;

import javax.batch.api.AbstractBatchlet;
import javax.inject.Named;

@Named
public class Batchlet extends AbstractBatchlet {

	public Batchlet() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String process() {
		// TODO Auto-generated method stub
		return null;
	}

}
