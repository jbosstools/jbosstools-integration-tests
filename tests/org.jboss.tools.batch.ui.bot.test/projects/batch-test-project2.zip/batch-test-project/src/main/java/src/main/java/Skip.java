package src.main.java;

import java.util.List;

import javax.batch.api.chunk.listener.SkipWriteListener;
import javax.inject.Named;

@Named
public class Skip implements SkipWriteListener {

	public Skip() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onSkipWriteItem(List<Object> arg0, Exception arg1) throws Exception {
		// TODO Auto-generated method stub

	}

}
