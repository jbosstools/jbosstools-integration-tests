package src.main.java;

import javax.batch.api.chunk.AbstractCheckpointAlgorithm;
import javax.inject.Named;

@Named
public class CheckpointAlgorithm extends AbstractCheckpointAlgorithm {

	public CheckpointAlgorithm() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isReadyToCheckpoint() throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
