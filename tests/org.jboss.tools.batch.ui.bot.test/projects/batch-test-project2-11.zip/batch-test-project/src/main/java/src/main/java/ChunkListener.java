package src.main.java;

import javax.batch.api.chunk.listener.AbstractChunkListener;
import javax.inject.Named;

@Named
public class ChunkListener extends AbstractChunkListener {

	public ChunkListener() {
		// TODO Auto-generated constructor stub
	}

}
