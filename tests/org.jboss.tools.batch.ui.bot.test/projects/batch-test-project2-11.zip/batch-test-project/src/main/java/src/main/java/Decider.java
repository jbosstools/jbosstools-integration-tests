package src.main.java;

import javax.batch.runtime.StepExecution;
import javax.inject.Named;

@Named
public class Decider implements javax.batch.api.Decider {

	public Decider() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String decide(StepExecution[] executions) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
